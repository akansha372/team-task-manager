require('dotenv').config();

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect(process.env.MONGO_URI);

// Models
const User = mongoose.model("User", {
  name:String,
  email:String,
  password:String,
  role:String
});

const Project = mongoose.model("Project", {
  name:String,
  members:[String]
});

const Task = mongoose.model("Task", {
  title:String,
  status:String,
  projectId:String,
  assignedTo:String,
  dueDate:Date
});

// Auth middleware
const auth = (req,res,next)=>{
  const token = req.headers.authorization;
  if(!token) return res.status(401).send("No token");
  try{
    const decoded = jwt.verify(token,process.env.JWT_SECRET);
    req.user = decoded;
    next();
  }catch{
    res.status(401).send("Invalid token");
  }
};

// Routes
app.post("/signup", async(req,res)=>{
  const hash = await bcrypt.hash(req.body.password,10);
  const user = await User.create({...req.body,password:hash});
  res.json(user);
});

app.post("/login", async(req,res)=>{
  const user = await User.findOne({email:req.body.email});
  if(!user) return res.send("User not found");
  const match = await bcrypt.compare(req.body.password,user.password);
  if(!match) return res.send("Wrong password");
  const token = jwt.sign({id:user._id,role:user.role},process.env.JWT_SECRET);
  res.json({token});
});

// Project routes
app.post("/projects", auth, async(req,res)=>{
  if(req.user.role !== "admin") return res.send("Only admin allowed");
  const project = await Project.create(req.body);
  res.json(project);
});

app.get("/projects", auth, async(req,res)=>{
  const projects = await Project.find();
  res.json(projects);
});

// Task routes
app.post("/tasks", auth, async(req,res)=>{
  const task = await Task.create(req.body);
  res.json(task);
});

app.get("/tasks", auth, async(req,res)=>{
  const tasks = await Task.find();
  res.json(tasks);
});

app.listen(process.env.PORT,()=>console.log("Server running"));
