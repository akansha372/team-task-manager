
import { useState } from "react";

function App(){
 const [token,setToken] = useState(localStorage.getItem("token")||"");
 const [title,setTitle] = useState("");

 const login = async()=>{
  const res = await fetch("http://localhost:5000/login",{
   method:"POST",
   headers:{"Content-Type":"application/json"},
   body:JSON.stringify({email:"admin@test.com",password:"123456"})
  });
  const data = await res.json();
  localStorage.setItem("token",data.token);
  setToken(data.token);
 };

 const createTask = async()=>{
  await fetch("http://localhost:5000/tasks",{
   method:"POST",
   headers:{
    "Content-Type":"application/json",
    "authorization":token
   },
   body:JSON.stringify({title,status:"Todo"})
  });
  alert("Task Created");
 };

 return(
  <div style={{padding:"20px"}}>
   <h1>Task Manager</h1>
   <button onClick={login}>Login</button>
   <br/><br/>
   <input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Task"/>
   <button onClick={createTask}>Create Task</button>
  </div>
 );
}

export default App;
