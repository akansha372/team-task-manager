
# FINAL Team Task Manager (Submission Ready)

## Features
- JWT Authentication
- Role-based access (Admin/Member)
- Project & Task management
- React frontend

## Run
Backend:
cd backend
npm install
npm start

Frontend:
cd frontend
npm install
npm start

## Deploy
- Backend: Railway
- Frontend: Vercel

## Demo Steps
1. Signup
2. Login
3. Create Project (admin)
4. Create Task
5. View tasks
